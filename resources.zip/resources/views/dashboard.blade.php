<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard | Absensi Digital</title>

    @vite(['resources/css/absensi.css'])

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <script src="https://unpkg.com/lucide@latest"></script>
</head>

<body>

<div class="dashboard">

    <!-- SIDEBAR -->
    <aside class="sidebar">

        <div class="profile">
            <div class="profile-picture">
                A
            </div>

            <div class="profile-info">
                <h3>Admin</h3>
                <span>Absensi Digital</span>
            </div>
        </div>

        <div class="menu-title">
            MENU
        </div>

        <nav class="menu">

            <a href="/dashboard" class="menu-item active">
                <span class="menu-icon">
                    <i data-lucide="home"></i>
                </span>
                <span>Dashboard</span>
            </a>

            <a href="/students" class="menu-item">
                <span class="menu-icon">
                    <i data-lucide="users"></i>
                </span>
                <span>Data Siswa</span>
            </a>

            <a href="/classes" class="menu-item">
                <span class="menu-icon">
                    <i data-lucide="school"></i>
                </span>
                <span>Data Kelas</span>
            </a>

            <a href="/teachers" class="menu-item">
                <span class="menu-icon">
                    <i data-lucide="user-round"></i>
                </span>
                <span>Data Guru</span>
            </a>

            <a href="/qr-location" class="menu-item">
                <span class="menu-icon">
                    <i data-lucide="map-pin"></i>
                </span>
                <span>QR Location</span>
            </a>

            <a href="/qr-token" class="menu-item">
                <span class="menu-icon">
                    <i data-lucide="qr-code"></i>
                </span>
                <span>QR Token</span>
            </a>

            <a href="/attendance" class="menu-item">
                <span class="menu-icon">
                    <i data-lucide="clipboard-check"></i>
                </span>
                <span>Data Absensi</span>
            </a>

        </nav>

        <div class="sidebar-bottom">

            <form action="/logout" method="POST">
                @csrf

                <button type="submit" class="logout-button">
                    <span class="menu-icon">
                        <i data-lucide="log-out"></i>
                    </span>

                    <span>Keluar</span>
                </button>
            </form>

        </div>

    </aside>


    <!-- MAIN CONTENT -->
    <main class="main-content">

        <!-- TOP BAR -->
        <header class="topbar">

            <div>
                <p class="small-title">ADMIN DASHBOARD</p>
                <h1>Selamat Datang, Admin 👋</h1>
                <p class="subtitle">
                    Pantau aktivitas absensi sekolah dengan mudah.
                </p>
            </div>

            <div class="topbar-date">
                <div class="date-icon">
                    <i data-lucide="calendar-days"></i>
                </div>

                <div>
                    <span>Hari ini</span>
                    <strong>{{ date('d M Y') }}</strong>
                </div>
            </div>

        </header>


        <!-- STATISTICS -->
        <section class="statistics">

            <div class="stat-card">

                <div class="stat-icon">
                    <i data-lucide="graduation-cap"></i>
                </div>

                <div class="stat-content">
                    <span>Total Siswa</span>
                    <h2>120</h2>
                    <small>Data siswa terdaftar</small>
                </div>

            </div>


            <div class="stat-card">

                <div class="stat-icon">
                    <i data-lucide="school"></i>
                </div>

                <div class="stat-content">
                    <span>Total Kelas</span>
                    <h2>8</h2>
                    <small>Kelas aktif</small>
                </div>

            </div>


            <div class="stat-card">

                <div class="stat-icon">
                    <i data-lucide="user-round"></i>
                </div>

                <div class="stat-content">
                    <span>Total Guru</span>
                    <h2>24</h2>
                    <small>Guru terdaftar</small>
                </div>

            </div>


            <div class="stat-card">

                <div class="stat-icon attendance-icon">
                    <i data-lucide="clipboard-check"></i>
                </div>

                <div class="stat-content">
                    <span>Absensi Hari Ini</span>
                    <h2>96%</h2>
                    <small>Tingkat kehadiran</small>
                </div>

            </div>

        </section>


        <!-- CONTENT GRID -->
        <section class="content-grid">

            <!-- ATTENDANCE SUMMARY -->
            <div class="card attendance-card">

                <div class="card-header">
                    <div>
                        <span class="card-label">RINGKASAN</span>
                        <h2>Kehadiran Hari Ini</h2>
                    </div>

                    <button class="more-button">
                        <i data-lucide="more-horizontal"></i>
                    </button>
                </div>


                <div class="attendance-layout">

                    <div class="circle-progress">

                        <div class="circle-inner">
                            <strong>96%</strong>
                            <span>Hadir</span>
                        </div>

                    </div>


                    <div class="attendance-list">

                        <div class="attendance-item">
                            <span class="attendance-dot hadir"></span>

                            <div>
                                <strong>Hadir</strong>
                                <small>Siswa hadir hari ini</small>
                            </div>

                            <b>115</b>
                        </div>


                        <div class="attendance-item">
                            <span class="attendance-dot izin"></span>

                            <div>
                                <strong>Izin</strong>
                                <small>Siswa dengan izin</small>
                            </div>

                            <b>3</b>
                        </div>


                        <div class="attendance-item">
                            <span class="attendance-dot sakit"></span>

                            <div>
                                <strong>Sakit</strong>
                                <small>Siswa tidak masuk</small>
                            </div>

                            <b>2</b>
                        </div>


                        <div class="attendance-item">
                            <span class="attendance-dot alpha"></span>

                            <div>
                                <strong>Alpha</strong>
                                <small>Tanpa keterangan</small>
                            </div>

                            <b>0</b>
                        </div>

                    </div>

                </div>

            </div>


            <!-- QUICK ACTION -->
            <div class="card quick-card">

                <div class="card-header">
                    <div>
                        <span class="card-label">AKSES CEPAT</span>
                        <h2>Menu Utama</h2>
                    </div>
                </div>


                <div class="quick-menu">

                    <a href="/students" class="quick-item">
                        <div class="quick-icon">
                            <i data-lucide="user-plus"></i>
                        </div>

                        <div>
                            <strong>Data Siswa</strong>
                            <span>Kelola siswa</span>
                        </div>

                        <i data-lucide="chevron-right"></i>
                    </a>


                    <a href="/classes" class="quick-item">
                        <div class="quick-icon">
                            <i data-lucide="school"></i>
                        </div>

                        <div>
                            <strong>Data Kelas</strong>
                            <span>Kelola kelas</span>
                        </div>

                        <i data-lucide="chevron-right"></i>
                    </a>


                    <a href="/attendance" class="quick-item">
                        <div class="quick-icon">
                            <i data-lucide="clipboard-check"></i>
                        </div>

                        <div>
                            <strong>Data Absensi</strong>
                            <span>Lihat absensi</span>
                        </div>

                        <i data-lucide="chevron-right"></i>
                    </a>

                </div>

            </div>

        </section>


        <!-- RECENT ATTENDANCE -->
        <section class="card recent-card">

            <div class="card-header">

                <div>
                    <span class="card-label">AKTIVITAS</span>
                    <h2>Absensi Terbaru</h2>
                </div>

                <a href="/attendance" class="view-all">
                    Lihat semua
                    <i data-lucide="arrow-up-right"></i>
                </a>

            </div>


            <div class="table-wrapper">

                <table>

                    <thead>
                        <tr>
                            <th>Siswa</th>
                            <th>Kelas</th>
                            <th>Waktu</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody>

                        <tr>
                            <td>
                                <div class="student">
                                    <div class="student-avatar">AS</div>

                                    <div>
                                        <strong>Ahmad Setiawan</strong>
                                        <span>XI RPL 3</span>
                                    </div>
                                </div>
                            </td>

                            <td>XI RPL 3</td>

                            <td>07:05 WIB</td>

                            <td>
                                <span class="status hadir-status">
                                    Hadir
                                </span>
                            </td>
                        </tr>


                        <tr>
                            <td>
                                <div class="student">
                                    <div class="student-avatar">NP</div>

                                    <div>
                                        <strong>Nabila Putri</strong>
                                        <span>XI RPL 3</span>
                                    </div>
                                </div>
                            </td>

                            <td>XI RPL 3</td>

                            <td>07:08 WIB</td>

                            <td>
                                <span class="status hadir-status">
                                    Hadir
                                </span>
                            </td>
                        </tr>


                        <tr>
                            <td>
                                <div class="student">
                                    <div class="student-avatar">RF</div>

                                    <div>
                                        <strong>Rizky Firmansyah</strong>
                                        <span>XI RPL 2</span>
                                    </div>
                                </div>
                            </td>

                            <td>XI RPL 2</td>

                            <td>07:12 WIB</td>

                            <td>
                                <span class="status izin-status">
                                    Izin
                                </span>
                            </td>
                        </tr>

                    </tbody>

                </table>

            </div>

        </section>


        <footer>
            © {{ date('Y') }} Absensi Digital • Admin Panel
        </footer>

    </main>

</div>


<script>
    lucide.createIcons();
</script>

</body>
</html>