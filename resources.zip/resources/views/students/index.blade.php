<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Siswa - Absensi Digital</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'dark-green': '#485935',
                        'deep-green': '#3f522f',
                        'olive': '#93a267',
                        'sage': '#cadbb7',
                        'light-sage': '#e8f0df',
                        'white-bg': '#fbfbfb',
                        'text-main': '#26301f',
                        'muted-text': '#899080',
                        'border-color': '#e3e8dc',
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-light-sage text-text-main font-sans antialiased min-h-screen flex">

    <!-- SIDEBAR -->
    <aside class="w-[260px] bg-dark-green text-white flex flex-col justify-between p-7 min-h-screen sticky top-0 h-screen flex-shrink-0">
        <div>
            <!-- Profile Admin -->
            <div class="flex items-center gap-3 px-2 mb-9">
                <div class="w-12 h-12 rounded-[15px] bg-sage text-dark-green flex items-center justify-center font-bold text-lg">
                    A
                </div>
                <div>
                    <h3 class="font-bold text-sm text-white">Admin</h3>
                    <span class="text-[10px] text-[#dce6d2]">Absensi Digital</span>
                </div>
            </div>

            <!-- Menu Navigation -->
            <p class="text-[10px] font-bold text-[#dce6d2] tracking-[1.5px] uppercase mb-3 px-3">MENU</p>
            <nav class="space-y-1.5">
                <a href="/dashboard" class="flex items-center gap-3 px-3.5 py-3 rounded-[14px] text-xs font-medium text-white hover:bg-white/10 transition">
                    <i class="fa-solid fa-house w-5 text-center text-sm"></i> Dashboard
                </a>
                <a href="/siswa" class="flex items-center gap-3 px-3.5 py-3 rounded-[14px] text-xs font-bold bg-sage text-dark-green transition">
                    <i class="fa-solid fa-user-group w-5 text-center text-sm"></i> Data Siswa
                </a>
                <a href="/kelas" class="flex items-center gap-3 px-3.5 py-3 rounded-[14px] text-xs font-medium text-white hover:bg-white/10 transition">
                    <i class="fa-solid fa-school w-5 text-center text-sm"></i> Data Kelas
                </a>
                <a href="/guru" class="flex items-center gap-3 px-3.5 py-3 rounded-[14px] text-xs font-medium text-white hover:bg-white/10 transition">
                    <i class="fa-solid fa-user-tie w-5 text-center text-sm"></i> Data Guru
                </a>
                <a href="/qr-location" class="flex items-center gap-3 px-3.5 py-3 rounded-[14px] text-xs font-medium text-white hover:bg-white/10 transition">
                    <i class="fa-solid fa-location-dot w-5 text-center text-sm"></i> QR Location
                </a>
                <a href="/qr-token" class="flex items-center gap-3 px-3.5 py-3 rounded-[14px] text-xs font-medium text-white hover:bg-white/10 transition">
                    <i class="fa-solid fa-qrcode w-5 text-center text-sm"></i> QR Token
                </a>
                <a href="/absensi" class="flex items-center gap-3 px-3.5 py-3 rounded-[14px] text-xs font-medium text-white hover:bg-white/10 transition">
                    <i class="fa-solid fa-clipboard-user w-5 text-center text-sm"></i> Data Absensi
                </a>
            </nav>
        </div>

        <!-- Logout -->
        <a href="/logout" onclick="return confirm('Apakah Anda yakin ingin keluar?')" class="flex items-center gap-3 px-3.5 py-3 rounded-[14px] text-xs font-medium text-white hover:bg-white/10 transition mt-auto">
            <i class="fa-solid fa-right-from-bracket w-5 text-center text-sm"></i> Keluar
        </a>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="flex-1 bg-white-bg p-[42px] min-h-screen overflow-x-hidden">
        <!-- Topbar -->
        <div class="flex justify-between items-center mb-8">
            <div>
                <p class="text-[10px] font-bold text-olive tracking-[1.5px] uppercase mb-1">MANAJEMEN KESISWAAN</p>
                <h1 class="text-3xl font-bold text-dark-green">Data Siswa</h1>
            </div>
            <div class="bg-light-sage px-4 py-3 rounded-[16px] flex items-center gap-3">
                <div class="w-10 h-10 rounded-[12px] bg-olive text-white flex items-center justify-center">
                    <i class="fa-regular fa-calendar text-base"></i>
                </div>
                <div>
                    <span class="block text-[9px] text-muted-text">Hari ini</span>
                    <strong class="text-xs text-dark-green font-bold">10 Sep 2026</strong>
                </div>
            </div>
        </div>

        <!-- Filter & Search Bar -->
        <div class="bg-white p-5 rounded-[23px] border border-border-color shadow-sm mb-6 flex flex-wrap gap-4 items-center justify-between">
            <div class="flex gap-3 flex-1 min-w-[280px]">
                <div class="relative flex-1">
                    <i class="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-muted-text text-xs"></i>
                    <input type="text" placeholder="Cari NIS, Nama Siswa..." class="w-full pl-10 pr-4 py-2.5 bg-light-sage/40 border border-border-color rounded-[14px] text-xs focus:outline-none focus:border-olive transition">
                </div>
                <select class="bg-light-sage/40 border border-border-color rounded-[14px] px-3 py-2.5 text-xs text-text-main focus:outline-none focus:border-olive">
                    <option value="">Semua Kelas</option>
                    <option value="XI RPL 1">XI RPL 1</option>
                    <option value="XI RPL 2">XI RPL 2</option>
                    <option value="XI RPL 3">XI RPL 3</option>
                </select>
            </div>
            <button onclick="openModal('modalTambahSiswa')" class="bg-olive hover:bg-dark-green text-white px-5 py-2.5 rounded-[14px] text-xs font-bold flex items-center gap-2 transition shadow-sm">
                <i class="fa-solid fa-plus"></i> Tambah Siswa
            </button>
        </div>

        <!-- Table Data Siswa -->
        <div class="bg-white rounded-[23px] border border-border-color shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="border-b border-border-color text-[9px] font-semibold text-muted-text uppercase bg-light-sage/30">
                            <th class="p-4">Siswa</th>
                            <th class="p-4">NIS</th>
                            <th class="p-4">Kelas</th>
                            <th class="p-4">Lokasi Absen</th>
                            <th class="p-4">Waktu Scan</th>
                            <th class="p-4">Status</th>
                            <th class="p-4 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-border-color/50 text-xs text-text-main">
                        <tr class="hover:bg-light-sage/20 transition">
                            <td class="p-4 flex items-center gap-3">
                                <div class="w-9 h-9 rounded-[11px] bg-sage text-dark-green font-bold flex items-center justify-center text-xs">
                                    AS
                                </div>
                                <div>
                                    <strong class="block text-dark-green text-xs">Ahmad Setiawan</strong>
                                    <span class="text-[9px] text-muted-text">Laki-laki</span>
                                </div>
                            </td>
                            <td class="p-4 font-mono text-xs">20261001</td>
                            <td class="p-4"><span class="px-3 py-1 bg-light-sage text-dark-green rounded-full text-[10px] font-semibold">XI RPL 3</span></td>
                            <td class="p-4 text-xs"><i class="fa-solid fa-location-dot text-olive mr-1"></i> Gerbang Utama</td>
                            <td class="p-4 font-mono text-xs">06:12 WIB</td>
                            <td class="p-4">
                                <span class="px-3 py-1 bg-[#e4eed9] text-deep-green rounded-full text-[10px] font-bold">Hadir</span>
                            </td>
                            <td class="p-4 text-center">
                                <div class="flex items-center justify-center gap-1">
                                    <button onclick="openModal('modalDetailSiswa')" class="p-2 text-muted-text hover:text-dark-green rounded-[10px] hover:bg-light-sage transition"><i class="fa-solid fa-eye"></i></button>
                                    <button onclick="openModal('modalEditSiswa')" class="p-2 text-muted-text hover:text-olive rounded-[10px] hover:bg-light-sage transition"><i class="fa-solid fa-pen-to-square"></i></button>
                                    <button onclick="confirm('Hapus data siswa ini?')" class="p-2 text-muted-text hover:text-red-600 rounded-[10px] hover:bg-light-sage transition"><i class="fa-solid fa-trash"></i></button>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- MODAL DETAIL SISWA -->
    <div id="modalDetailSiswa" class="fixed inset-0 bg-dark-green/40 backdrop-blur-sm z-50 flex items-center justify-center hidden">
        <div class="bg-white rounded-[23px] w-full max-w-lg p-6 shadow-xl relative border border-border-color">
            <button onclick="closeModal('modalDetailSiswa')" class="absolute top-5 right-5 text-muted-text hover:text-dark-green">
                <i class="fa-solid fa-xmark text-xl"></i>
            </button>
            <div class="flex items-center gap-4 border-b border-border-color pb-4">
                <div class="w-14 h-14 rounded-[15px] bg-sage text-dark-green font-bold flex items-center justify-center text-xl">
                    AS
                </div>
                <div>
                    <h3 class="text-base font-bold text-dark-green">Ahmad Setiawan</h3>
                    <p class="text-xs text-muted-text">NIS: 20261001 • Kelas XI RPL 3</p>
                </div>
            </div>
            <div class="py-4 space-y-3">
                <div class="p-3 bg-light-sage/40 rounded-[14px]">
                    <span class="block text-[9px] text-muted-text uppercase font-bold mb-1">Status Absensi</span>
                    <p class="text-xs font-bold text-deep-green">Hadir Tepat Waktu (06:12 WIB)</p>
                </div>
                <div class="p-3 bg-light-sage/40 rounded-[14px]">
                    <span class="block text-[9px] text-muted-text uppercase font-bold mb-1">Lokasi Scan</span>
                    <p class="text-xs font-bold text-dark-green"><i class="fa-solid fa-location-dot text-olive mr-1"></i> Gerbang Utama Sekolah</p>
                </div>
            </div>
            <div class="flex justify-end pt-2">
                <button onclick="closeModal('modalDetailSiswa')" class="px-5 py-2.5 bg-light-sage text-dark-green font-bold text-xs rounded-[14px] hover:bg-sage transition">Tutup</button>
            </div>
        </div>
    </div>

    <!-- MODAL TAMBAH SISWA -->
    <div id="modalTambahSiswa" class="fixed inset-0 bg-dark-green/40 backdrop-blur-sm z-50 flex items-center justify-center hidden">
        <div class="bg-white rounded-[23px] w-full max-w-md p-6 shadow-xl relative border border-border-color">
            <button onclick="closeModal('modalTambahSiswa')" class="absolute top-5 right-5 text-muted-text hover:text-dark-green">
                <i class="fa-solid fa-xmark text-xl"></i>
            </button>
            <h3 class="text-base font-bold text-dark-green mb-4 border-b border-border-color pb-3">Tambah Data Siswa</h3>
            <form class="space-y-3">
                <div>
                    <label class="block text-[10px] font-bold text-dark-green mb-1">Nama Lengkap</label>
                    <input type="text" class="w-full px-3.5 py-2 bg-light-sage/30 border border-border-color rounded-[14px] text-xs focus:outline-none focus:border-olive" placeholder="Masukkan nama siswa">
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-[10px] font-bold text-dark-green mb-1">NIS</label>
                        <input type="text" class="w-full px-3.5 py-2 bg-light-sage/30 border border-border-color rounded-[14px] text-xs focus:outline-none focus:border-olive" placeholder="2026xxxx">
                    </div>
                    <div>
                        <label class="block text-[10px] font-bold text-dark-green mb-1">Kelas</label>
                        <select class="w-full px-3.5 py-2 bg-light-sage/30 border border-border-color rounded-[14px] text-xs focus:outline-none focus:border-olive">
                            <option value="XI RPL 1">XI RPL 1</option>
                            <option value="XI RPL 2">XI RPL 2</option>
                            <option value="XI RPL 3">XI RPL 3</option>
                        </select>
                    </div>
                </div>
                <div class="flex justify-end gap-2 pt-3 border-t border-border-color">
                    <button type="button" onclick="closeModal('modalTambahSiswa')" class="px-4 py-2 bg-light-sage text-dark-green rounded-[14px] text-xs font-bold hover:bg-sage transition">Batal</button>
                    <button type="submit" class="px-4 py-2 bg-olive text-white rounded-[14px] text-xs font-bold hover:bg-dark-green transition">Simpan</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openModal(id) { document.getElementById(id).classList.remove('hidden'); }
        function closeModal(id) { document.getElementById(id).classList.add('hidden'); }
    </script>
</body>
</html>