<!-- Google Fonts: Inter -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

<script src="https://cdn.tailwindcss.com"></script>
<script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    'dark-green': '#485935',
                    'deep-green': '#3f522f',
                    'olive': '#93a267',
                    'sage': '#cadbb7',
                    'light-sage': '#e8f0df',
                    'white-bg': '#fbfbfb',
                    'text-main': '#26301f',
                    'muted-text': '#899080',
                    'border-color': '#e3e8dc',
                },
                fontFamily: {
                    sans: ['Inter', 'sans-serif'],
                }
            }
        }
    }
</script>